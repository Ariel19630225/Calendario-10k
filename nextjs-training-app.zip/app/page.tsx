import { useState } from "react";

const startDate = new Date();

const generateWeek = (baseDate, offset = 0) => {
  const start = new Date(baseDate);
  start.setDate(start.getDate() + offset * 7);
  return Array.from({ length: 7 }, (_, i) => {
    const d = new Date(start);
    d.setDate(d.getDate() + i);
    return d;
  });
};

export default function Home() {
  const [weekOffset, setWeekOffset] = useState(0);
  const [activities, setActivities] = useState({});

  const currentWeek = generateWeek(startDate, weekOffset);

  const handleChange = (date, value) => {
    setActivities((prev) => ({ ...prev, [date]: value }));
  };

  return (
    <div style={{ padding: "2rem", fontFamily: "sans-serif" }}>
      <h1 style={{ fontSize: "1.5rem", fontWeight: "bold" }}>Calendario de Entrenamiento 10K</h1>
      <div style={{ display: "flex", justifyContent: "space-between", margin: "1rem 0" }}>
        <button onClick={() => setWeekOffset(weekOffset - 1)}>Semana anterior</button>
        <button onClick={() => setWeekOffset(weekOffset + 1)}>Semana siguiente</button>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "1rem" }}>
        {currentWeek.map((date) => {
          const dateStr = date.toISOString().split("T")[0];
          return (
            <div key={dateStr} style={{ border: "1px solid #ccc", borderRadius: "10px", padding: "1rem", background: "#fff" }}>
              <h2 style={{ fontWeight: "bold", textAlign: "center" }}>
                {date.toLocaleDateString("es-ES", { weekday: "long", day: "numeric", month: "short" })}
              </h2>
              <textarea
                style={{ width: "100%", marginTop: "0.5rem", padding: "0.5rem", borderRadius: "5px" }}
                rows={4}
                value={activities[dateStr] || ""}
                onChange={(e) => handleChange(dateStr, e.target.value)}
              />
            </div>
          );
        })}
      </div>
    </div>
  );
}
